package com.prc.ContainerOptimizationApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContainerOptimizationApplication {
    public static void main(String[] args) {
        SpringApplication.run(ContainerOptimizationApplication.class, args);
    }
}