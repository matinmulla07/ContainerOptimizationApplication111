package com.prc.ContainerOptimizationApplication.controller;

import com.prc.ContainerOptimizationApplication.model.Container;
import com.prc.ContainerOptimizationApplication.service.OptimizationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/optimize")
public class OptimizationController {

    @Autowired
    private OptimizationService optimizationService;

    @PostMapping
    public List<Container> optimize(@RequestBody List<Container> containers) {
        return optimizationService.optimize(containers);
    }
}