package com.prc.ContainerOptimizationApplication.service;

import com.prc.ContainerOptimizationApplication.dao.ContainerRepository;
import com.prc.ContainerOptimizationApplication.model.Container;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OptimizationService {

    @Autowired
    private ContainerRepository containerRepository;

    public List<Container> optimize(List<Container> containers) {
        containerRepository.saveAll(containers);
        return containerRepository.findAll()
                .stream()
                .sorted((c1, c2) -> c1.getId().compareTo(c2.getId()))
                .collect(Collectors.toList());
    }
}