# Container Optimization API

## Overview
This API accepts a list of containers, saves them, and returns an optimized (sorted) move plan.

## API Details

- **POST /optimize**
- Request Body:
```json
[{"id": "C3"}, {"id": "C1"}, {"id": "C2"}]
```
- Response:
```json
[{"id": "C1"}, {"id": "C2"}, {"id": "C3"}]
```

## How to Run
- Make sure PostgreSQL DB is up.
- Correct DB details inside `application.properties`.
- Run Spring Boot app.

## How to Test
Use Postman:
- URL: `http://localhost:8080/optimize`
- Method: `POST`
- Body: raw JSON (application/json)

## Latency Benchmark
- ~30ms - 70ms response time for 5-10 containers.